﻿function ATMAddress() {
	this.title = '';
	this.add1 = '';
	this.add2 = '';
	this.imageurl = '' ;
	this.workphone = '';
	this.distance = '';
	this.atmnetworkid = '';
	this.zIndex = '';
	
	this.getTitle = function() {
	    return this.title;
	}
	
	this.setTitle = function (title) {
	    this.title = title;
	}
	
	this.getAdd1 = function() {
	    return this.add1;
	}
	
	this.setAdd1 = function (add1) {
	    this.add1 = add1;
	}
	this.getAdd2 = function() {
	    return this.add2;
	}
	
	this.setAdd2 = function (add2) {
	    this.add2 = add2;
	}
	this.getWorkPhone = function() {
	    return this.workphone;
	}
	
	this.setWorkPhone = function (workphone) {
	    this.workphone = workphone;
	}
	
	this.getDistance = function() {
	    return this.distance;
	}
	
	this.setDistance = function (distance) {
	    this.distance = distance;
	}
	this.getImageUrl = function() {
	    return this.imageurl;
	}
	
	this.setImageUrl = function (imageurl) {
	    this.imageurl = imageurl;
	}
	
	
	this.getATMNetworkid = function() {
	    return this.atmnetworkid;
	}
	
	this.setATMNetworkid = function (atmnetworkid) {
	    this.atmnetworkid = atmnetworkid;
	}
	this.getzIndex = function () {
	    return this.zIndex;
	}

	this.setzIndex = function (zIndex) {
	    this.zIndex = zIndex;
	}
}