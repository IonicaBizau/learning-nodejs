﻿function Dhtml() {

    this.showElement = function (elm) {
	    if(document.getElementById(elm) != null && document.getElementById(elm) != 'undefined') {
		    document.getElementById(elm).style.visibility = 'visible';
		    document.getElementById(elm).style.display = 'block';
	    }
    }

    this.hideElement = function (elm) {
	    if(document.getElementById(elm) != null && document.getElementById(elm) != 'undefined') {
		    document.getElementById(elm).style.visibility = 'hidden';	
		    document.getElementById(elm).style.display = 'none';
	    }
    	
    }

    this.setText = function (elm,txt) {
	    if(document.getElementById(elm) != null && document.getElementById(elm) != 'undefined') 
		    document.getElementById(elm).innerHTML = txt;
    }
    
    this.getText = function(elm) {
        return document.getElementById(elm).innerHTML;
    }
    
    this.isVisible = function (elm) {
	    flag = false;
	    if(document.getElementById(elm) != null) {
		    if((document.getElementById(elm).style.visibility == 'visible') || (document.getElementById(elm).style.display=='block'))
			    flag = true;
		    else
			    flag = false;
	    }
	    return flag;
    }
    
    this.isParentVisible = function (elm) {
	    flag = false;
	    if(opener.document.getElementById(elm) != null) {
		    if((opener.document.getElementById(elm).style.visibility == 'visible') || (opener.document.getElementById(elm).style.display=='block'))
			    flag = true;
		    else
			    flag = false;
	    }
	    return flag;
    }

	this.setBounds = function (elm,left,top,width,height) {
		if(document.getElementById(elm) != null) {
		    document.getElementById(elm).style.left = left + 'px';
			document.getElementById(elm).style.top = top + 'px';
			if(width != null) {
				document.getElementById(elm).style.width  = width + 'px';
			}
			if(height != null) {
				document.getElementById(elm).style.height = height + 'px';
			}
	    }
	}

	this.getWidth = function (elm) {
		width = 0;
		if(document.getElementById(elm) != null) {
			width = document.getElementById(elm).style.width;
		}
		return parseInt(width);
	}
}