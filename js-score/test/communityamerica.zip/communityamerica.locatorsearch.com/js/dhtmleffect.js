﻿dhtml = new Dhtml();

function toggleLocate(obj) {
    if(obj.className == 'toggleFeaturesClosed') {
        obj.className = 'toggleFeaturesOpened';
        
        document.getElementById('advanceSearch').className = 'toggleSearchOpened';
        
        dhtml.hideElement('searchResultContent');
        dhtml.showElement('searchInput');
        dhtml.hideElement('directionResult');
        
        document.getElementById('locateResult').className = 'toggleFeaturesClosed';
        document.getElementById('direction').className = 'toggleFeaturesClosed';
    }
    else {
//        obj.className = 'toggleFeaturesClosed';
//        document.getElementById('advanceSearch').className = 'toggleSearchClosed';
//        dhtml.hideElement('searchInput');
    }
}

function toggleAdvanceSearch(obj) {
    if(obj.className == 'toggleSearchOpened') {
        obj.className = 'toggleSearchClosed'
        dhtml.hideElement('searchInput');
        document.getElementById('locate').className = 'toggleFeaturesClosed';
    }
    else {
        obj.className = 'toggleSearchOpened'
        dhtml.showElement('searchInput');
        document.getElementById('locate').className = 'toggleFeaturesOpened';
        dhtml.hideElement('searchResultContent');
        dhtml.hideElement('directionResult');
        
        document.getElementById('locateResult').className = 'toggleFeaturesClosed';
        document.getElementById('direction').className = 'toggleFeaturesClosed';
        
    }
}

function toggleResult(obj) {
    if(obj.className == 'toggleFeaturesClosed') {
        obj.className = 'toggleFeaturesOpened';
        
 //       dhtml.hideElement('searchInput');
        dhtml.showElement('searchResultContent');
        dhtml.hideElement('directionResult');
        
 //       document.getElementById('advanceSearch').className = 'toggleSearchClosed';
        document.getElementById('locate').className = 'toggleFeaturesClosed';
        document.getElementById('direction').className = 'toggleFeaturesClosed';
    }
    else {
        obj.className = 'toggleFeaturesClosed';
        dhtml.hideElement('searchResultContent');
    }
}

function toggleDirection(obj) {
    if(obj.className == 'toggleFeaturesClosed') {
        
        obj.className = 'toggleFeaturesOpened';
        
//        dhtml.hideElement('searchInput');
        dhtml.hideElement('searchResultContent');
        dhtml.showElement('directionResult');
        
//        document.getElementById('advanceSearch').className = 'toggleSearchClosed';
        document.getElementById('locate').className = 'toggleFeaturesClosed';
        document.getElementById('locateResult').className = 'toggleFeaturesClosed';
        
    }
    else {
        obj.className = 'toggleFeaturesClosed';
        dhtml.hideElement('directionResult');
    }
}

function showSearchResult() {
    document.getElementById('locate').className = 'toggleFeaturesClosed'
//    document.getElementById('advanceSearch').className = 'toggleSearchClosed';
    document.getElementById('locateResult').className = 'toggleFeaturesOpened'
    document.getElementById('direction').className = 'toggleFeaturesClosed'
    dhtml.showElement('searchResultContent');
//    dhtml.hideElement('searchInput');
    dhtml.hideElement('directionResult');
}

function showDirectionResult() {
    document.getElementById('locate').className = 'toggleFeaturesClosed'
//    document.getElementById('advanceSearch').className = 'toggleSearchClosed';
    document.getElementById('direction').className = 'toggleFeaturesOpened'
    document.getElementById('locateResult').className = 'toggleFeaturesClosed'
    dhtml.hideElement('searchResultContent');
//    dhtml.hideElement('searchInput');
    dhtml.showElement('directionResult');
}