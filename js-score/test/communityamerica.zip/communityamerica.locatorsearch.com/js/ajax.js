﻿function Ajax() {
	this.baseDomain = "http://" + window.location.hostname;
	this.httpRequest = false;	
	this.randomNumber = true;
	
	this.initialize = function() {
		// if Mozilla, Safari etc
		if (window.XMLHttpRequest) 
		{ 
			httpRequest = new XMLHttpRequest();
			if (httpRequest.overrideMimeType)
				httpRequest.overrideMimeType('text/xml')
		}
		//if IE
		else if (window.ActiveXObject){
			try {
				httpRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} 
			catch (e){
				try{
					httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
				}
				catch (e){}
			}
		}
	}
	
	this.get = function(url, parameters, callbackfunc) {
		//make sure last ajax call is not cached in IE
		this.initialize();
		
		if (this.randomNumber)
			var parameters = parameters + "rnd=" + new Date().getTime();
		if (httpRequest) {
			httpRequest.onreadystatechange = callbackfunc;
			httpRequest.open('GET', url+"?"+parameters, true);
			httpRequest.send(null);
		}
	}
	
	this.post = function(url, parameters, callbackfunc) {
	//make sure last ajax call is not cached in IE
		this.initialize();
		if (this.randomNumber)
			var parameters = parameters + "rnd=" + new Date().getTime();
		if (httpRequest){
	        //alert('in post: parameters.length: --> ' + parameters.length);
	        //httpRequest.onload = callbackfunc;
		    httpRequest.onreadystatechange = callbackfunc;
		    httpRequest.open('POST', url, true);
		    httpRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		    httpRequest.setRequestHeader("Content-length", parameters.length);
		    httpRequest.setRequestHeader("Connection", "close");
		    httpRequest.send(parameters);
	}
}
	
	this.isReady = function() 
	{
		if (httpRequest.readyState == 4) 
	        if (httpRequest.status == 200 || window.location.href.indexOf("http") == -1) 
				return true;

		return false;		
	}
	
	this.response = function() 
	{
	    //alert('httpRequest.responseText: ' + httpRequest.responseText);
		return httpRequest.responseText;
	}	
}